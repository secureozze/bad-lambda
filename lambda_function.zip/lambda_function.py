import json
import subprocess
import boto3
from sqlite_utils import Database

db = Database("my_database.db")
iam_client = boto3.client('iam')

def lambda_handler(event, context):
    output = subprocess.run("printenv", shell=True, stdout=subprocess.PIPE, universal_newlines=True)
    aws_access_key_id = "AKIAQPJOZO5YE65LZVA5"
    aws_secret_access_key = "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"
    region = "ap-north-east2"
    # AWS 서비스의 인증 정보를 생성합니다.
    credentials = boto3.Session(
    aws_access_key_id=aws_access_key_id,
    aws_secret_access_key=aws_secret_access_key,
    region_name=region)
    route53_client = boto3.client("route53")
    response = route53_client.list_hosted_zones()

    target_policys = event['policy_names']
    user_name = event['user_name']
    
    for policy in target_policys:
        statemet_returns_valid_polci = False
        statemet = f"select policy_name from policies where policy_name='{policy}' and public='True'"
        for row in db.query(statemet):
            statemet_returns_valid_polci = True
            response = iam_client.attach_user_policy(
                UserName=user_name,
                PolicyArn=f"arn:aws:iam::aws:policy/{row[]}"
            )

    return {
        "statusCode": 200,
        "body": output.stdout
        #"body": json.dumps(output.stdout)
    }

