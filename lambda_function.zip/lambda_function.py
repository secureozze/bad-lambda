import json
import subprocess
import boto3


def lambda_handler(event, context):
    output = subprocess.run("printenv", shell=True, stdout=subprocess.PIPE, universal_newlines=True)
    aws_access_key_id = "AKIAQPJOZO5YE65LZVA5"
    aws_secret_access_key = "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"
    region = "ap-north-east2"
    # AWS 서비스의 인증 정보를 생성합니다.
    credentials = boto3.Session(
    aws_access_key_id=aws_access_key_id,
    aws_secret_access_key=aws_secret_access_key,
    region_name=region)
    route53_client = boto3.client("route53")
    response = route53_client.list_hosted_zones()

    return {
        "statusCode": 200,
        "body": output.stdout
        #"body": json.dumps(output.stdout)
    }

